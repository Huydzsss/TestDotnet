global using static System.Console;

global using System.Globalization;

global using System.Linq;

global using Microsoft.EntityFrameworkCore;
global using BCrypt;